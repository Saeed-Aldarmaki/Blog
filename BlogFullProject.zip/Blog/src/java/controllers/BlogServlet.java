package controllers;

import models.Blog;
import models.Comment;
import utils.DBConnection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.annotation.WebServlet;

@WebServlet("/BlogServlet")
public class BlogServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String blogIdParam = request.getParameter("id");
        if (blogIdParam == null || blogIdParam.trim().isEmpty()) {
            System.out.println("Blog ID is missing in the request.");
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Blog ID is required");
            return;
        }

        int blogId = Integer.parseInt(blogIdParam);
        System.out.println("Blog ID received: " + blogId);

        try (Connection conn = DBConnection.getConnection()) {
            // Fetch blog details
            String blogSql = "SELECT Blogs.blog_id, Blogs.title, Blogs.content, Blogs.image, Blogs.created_at, Users.username " +
                             "FROM Blogs " +
                             "JOIN Users ON Blogs.user_id = Users.user_id " +
                             "WHERE Blogs.blog_id = ?";
            PreparedStatement blogStmt = conn.prepareStatement(blogSql);
            blogStmt.setInt(1, blogId);
            ResultSet blogRs = blogStmt.executeQuery();

            Blog blog = null;
            if (blogRs.next()) {
                System.out.println("Blog found in the database: " + blogRs.getString("title"));
                blog = new Blog();
                blog.setId(blogRs.getInt("blog_id"));
                blog.setTitle(blogRs.getString("title"));
                blog.setContent(blogRs.getString("content"));
                blog.setImage(blogRs.getString("image"));
                blog.setCreatedAt(blogRs.getTimestamp("created_at"));
                blog.setAuthor(blogRs.getString("username"));
            } else {
                System.out.println("No blog found for the given ID.");
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Blog not found");
                return;
            }

            // Fetch like count
            String likesSql = "SELECT COUNT(*) AS total_likes FROM Likes WHERE blog_id = ?";
            PreparedStatement likesStmt = conn.prepareStatement(likesSql);
            likesStmt.setInt(1, blogId);
            ResultSet likesRs = likesStmt.executeQuery();
            if (likesRs.next()) {
                blog.setLikeCount(likesRs.getInt("total_likes"));
            }

            // Fetch comments
            String commentsSql = "SELECT Users.username, Users.user_id, Comments.comment_id, Comments.comment_text, Comments.created_at " +
                                 "FROM Comments " +
                                 "JOIN Users ON Comments.user_id = Users.user_id " +
                                 "WHERE Comments.blog_id = ? ORDER BY Comments.created_at DESC";
            PreparedStatement commentsStmt = conn.prepareStatement(commentsSql);
            commentsStmt.setInt(1, blogId);
            ResultSet commentsRs = commentsStmt.executeQuery();

            List<Comment> comments = new ArrayList<>();
            while (commentsRs.next()) {
                Comment comment = new Comment();
                comment.setId(commentsRs.getInt("comment_id"));
                comment.setUsername(commentsRs.getString("username"));
                comment.setCommentText(commentsRs.getString("comment_text"));
                comment.setCreatedAt(commentsRs.getTimestamp("created_at"));
                comment.setUserId(commentsRs.getInt("user_id"));
                comments.add(comment);
            }
            blog.setComments(comments);

            request.setAttribute("blog", blog);
            RequestDispatcher dispatcher = request.getRequestDispatcher("blog.jsp");
            dispatcher.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while processing the request");
        }
    }
}
