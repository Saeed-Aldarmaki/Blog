package controllers;

import utils.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/CommentServlet")
public class CommentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        models.User user = (models.User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("index.jsp"); // Redirect to login if user is not logged in
            return;
        }

        String action = request.getParameter("action");
        int userId = user.getId();

        if ("delete".equals(action)) {
            handleDeleteComment(request, response, userId);
        } else {
            handleAddComment(request, response, userId);
        }
    }

    private void handleAddComment(HttpServletRequest request, HttpServletResponse response, int userId) throws IOException {
        String commentText = request.getParameter("comment_text");
        String blogIdParam = request.getParameter("blog_id");

        if (commentText == null || commentText.trim().isEmpty() || blogIdParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input");
            return;
        }

        int blogId = Integer.parseInt(blogIdParam);

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO Comments (user_id, blog_id, comment_text) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, blogId);
            stmt.setString(3, commentText);
            stmt.executeUpdate();

            response.sendRedirect("BlogServlet?id=" + blogId); // Redirect to the blog details page
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while adding the comment.");
        }
    }

    private void handleDeleteComment(HttpServletRequest request, HttpServletResponse response, int userId) throws IOException {
        String commentIdParam = request.getParameter("comment_id");

        if (commentIdParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Comment ID is required");
            return;
        }

        int commentId = Integer.parseInt(commentIdParam);

        System.out.println("Attempting to delete comment. Comment ID: " + commentId + ", User ID: " + userId);

        try (Connection conn = DBConnection.getConnection()) {
            // Validate and delete the comment if it belongs to the user
            String sql = "DELETE FROM Comments WHERE comment_id = ? AND user_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, commentId);
            stmt.setInt(2, userId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected == 0) {
                System.out.println("Delete failed. Either the comment does not exist, or the user is not authorized.");
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You are not authorized to delete this comment");
                return;
            }

            System.out.println("Comment deleted successfully.");
            response.sendRedirect(request.getHeader("Referer")); // Redirect back to the previous page
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while deleting the comment.");
        }
    }

}
