package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import models.User;
import utils.DBConnection;

@WebServlet("/CreateBlogServlet")
public class CreateBlogServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Retrieve form data
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String imageUrl = request.getParameter("image");

        // Validate input
        if (title == null || title.trim().isEmpty() ||
            content == null || content.trim().isEmpty() ||
            imageUrl == null || imageUrl.trim().isEmpty()) {
            response.setContentType("text/html");
            response.getWriter().println("<p>Error: All fields are required!</p>");
            return;
        }

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO Blogs (title, content, image, created_at, user_id) VALUES (?, ?, ?, NOW(), ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, title);
                pstmt.setString(2, content);
                pstmt.setString(3, imageUrl); // Store the URL directly
                pstmt.setInt(4, user.getId());

                pstmt.executeUpdate();

                // Success response
                response.setContentType("text/html");
                response.getWriter().println("<div style='display: flex; justify-content: center; align-items: center; height: 100vh;'>");
                response.getWriter().println("<div style='width: 80%; display: flex; justify-content: center;'>");
                response.getWriter().println("<div style='padding: 20px; width: 100%; max-width: 800px; text-align: center; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 5px;'>");
                response.getWriter().println("<p style='font-size: 20px; font-weight: bold;'>Blog post created successfully!</p>");
                response.getWriter().println("<a href='HomeServlet' style='color: #155724; text-decoration: none; font-size: 18px; font-weight: bold; padding: 10px 20px; border: 1px solid #155724; border-radius: 5px; display: inline-block; transition: background-color 0.3s, color 0.3s;' onmouseover='this.style.backgroundColor=\"#155724\"; this.style.color=\"#ffffff\";' onmouseout='this.style.backgroundColor=\"transparent\"; this.style.color=\"#155724\";'>Go back to homepage</a>");
                response.getWriter().println("</div>");
                response.getWriter().println("</div>");
                response.getWriter().println("</div>");
            }
        } catch (Exception e) {
            // Error response
            response.setContentType("text/html");
            response.getWriter().println("<p>Error saving to database: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }
    }
}
