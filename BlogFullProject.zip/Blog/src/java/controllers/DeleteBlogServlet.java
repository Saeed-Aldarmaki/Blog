package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deletePost")
public class DeleteBlogServlet extends HttpServlet {

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/blog?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String postId = request.getParameter("id");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Posts WHERE post_id = ?")) {

            // Set the post ID in the query
            stmt.setString(1, postId);

            // Execute the update
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                    // Success response
            response.setContentType("text/html");
            response.getWriter().println("<div style='display: flex; justify-content: center; align-items: center; height: 100vh;'>");
            response.getWriter().println("<div style='width: 80%; display: flex; justify-content: center;'>");
            response.getWriter().println("<div style='padding: 20px; width: 100%; max-width: 800px; text-align: center; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 5px;'>");
            response.getWriter().println("<p style='font-size: 20px; font-weight: bold;'>Blog post deleted successfully!</p>");
            response.getWriter().println("<a href='main.jsp' style='color: #155724; text-decoration: none; font-size: 18px; font-weight: bold; padding: 10px 20px; border: 1px solid #155724; border-radius: 5px; display: inline-block; transition: background-color 0.3s, color 0.3s;' onmouseover='this.style.backgroundColor=\"#155724\"; this.style.color=\"#ffffff\";' onmouseout='this.style.backgroundColor=\"transparent\"; this.style.color=\"#155724\";'>Go back to homepage</a>");
            response.getWriter().println("</div>");
            response.getWriter().println("</div>");
            response.getWriter().println("</div>");
            } else {
                // Display an error message if no rows were affected
                response.getWriter().println("<p>Failed to delete post.</p>");
            }

        } catch (Exception e) {
            // Handle any exceptions
            response.getWriter().println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
