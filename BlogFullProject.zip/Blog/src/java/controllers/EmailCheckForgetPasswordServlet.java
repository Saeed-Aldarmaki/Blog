import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/EmailCheckForgetPasswordServlet"})
public class EmailCheckForgetPasswordServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String email = request.getParameter("email");
        String databaseURL = "jdbc:mysql://localhost:3306/blog";
        String driverName = "com.mysql.cj.jdbc.Driver";
        String user = "root";
        String dbPassword = "root";

        // SQL query to check if the email exists in the database
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try (PrintWriter out = response.getWriter()) {
            // Load MySQL JDBC Driver
            Class.forName(driverName).newInstance();
            // Establish connection to the database
            con = DriverManager.getConnection(databaseURL, user, dbPassword);

            // Prepare the SQL query
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, email); // Set the email parameter

            // Execute the query
            rs = pstmt.executeQuery();

          if (rs.next() && rs.getInt(1) > 0) {
    // Email exists
    out.println("<html>");
    out.println("<head>");
    out.println("<style>");
    out.println("body {");
    out.println("    font-family: Arial, sans-serif;");
    out.println("    background-color: #f0f0f0;");
    out.println("    display: flex;");
    out.println("    justify-content: center;");
    out.println("    align-items: center;");
    out.println("    height: 100vh;");
    out.println("    margin: 0;");
    out.println("}");
    out.println(".container {");
    out.println("    background-color: #fff;");
    out.println("    padding: 20px;");
    out.println("    border-radius: 8px;");
    out.println("    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);");
    out.println("    text-align: center;");
    out.println("    max-width: 400px;");
    out.println("    width: 100%;");
    out.println("}");
    out.println(".container a {");
    out.println("    display: inline-block;");
    out.println("    margin-top: 15px;");
    out.println("    padding: 10px 15px;");
    out.println("    background-color: #4CAF50;");
    out.println("    color: white;");
    out.println("    border-radius: 4px;");
    out.println("    text-decoration: none;");
    out.println("    transition: background-color 0.3s;");
    out.println("}");
    out.println(".container a:hover {");
    out.println("    background-color: #45a049;");
    out.println("}");
    out.println("</style>");
    out.println("</head>");
    out.println("<body>");
    out.println("<div class='container'>");
    out.println("<p>Email exists in the database. You can proceed with resetting the password.</p>");
    out.println("<a href='resetPassword.jsp'>Reset Password</a>"); // Link to the reset password page
    out.println("</div>");
    out.println("</body>");
    out.println("</html>");
} else {
    // Email does not exist
    out.println("<html>");
    out.println("<head>");
    out.println("<style>");
    out.println("body {");
    out.println("    font-family: Arial, sans-serif;");
    out.println("    background-color: #f8d7da;"); // Light red background for error
    out.println("    display: flex;");
    out.println("    justify-content: center;");
    out.println("    align-items: center;");
    out.println("    height: 100vh;");
    out.println("    margin: 0;");
    out.println("}");
    out.println(".container {");
    out.println("    background-color: #fff;");
    out.println("    padding: 20px;");
    out.println("    border-radius: 8px;");
    out.println("    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);");
    out.println("    text-align: center;");
    out.println("    max-width: 400px;");
    out.println("    width: 100%;");
    out.println("}");
    out.println(".container a {");
    out.println("    display: inline-block;");
    out.println("    margin-top: 15px;");
    out.println("    padding: 10px 15px;");
    out.println("    background-color: #dc3545;");
    out.println("    color: white;");
    out.println("    border-radius: 4px;");
    out.println("    text-decoration: none;");
    out.println("    transition: background-color 0.3s;");
    out.println("}");
    out.println(".container a:hover {");
    out.println("    background-color: #b02a37;");
    out.println("}");
    out.println("</style>");
    out.println("</head>");
    out.println("<body>");
    out.println("<div class='container'>");
    out.println("<p>Email does not exist. Please check the entered email.</p>");
    out.println("<a href='forgetpassword.jsp'>Try Again</a>"); // Link back to the forgot password page
    out.println("</div>");
    out.println("</body>");
    out.println("</html>");
}

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet to check if the email exists in the database.";
    }
}
