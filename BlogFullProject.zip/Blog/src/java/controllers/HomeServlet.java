package controllers;

import models.Blog;
import models.User;
import utils.DBConnection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            // Redirect to login page if user is not logged in
            response.sendRedirect("index.jsp");
            return;
        }

        // Create a list to hold blogs
        List<Blog> blogs = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection()) {
            // Fetch blogs along with their authors
            String blogSql = "SELECT Blogs.blog_id, Blogs.title, Blogs.content, Blogs.image, Blogs.created_at, Users.username " +
                             "FROM blogs " +
                             "JOIN Users ON Blogs.user_id = Users.user_id";

            PreparedStatement blogStmt = conn.prepareStatement(blogSql);
            ResultSet blogRs = blogStmt.executeQuery();

            while (blogRs.next()) {
                Blog blog = new Blog();
                blog.setId(blogRs.getInt("blog_id"));
                blog.setTitle(blogRs.getString("title"));
                blog.setContent(blogRs.getString("content"));
                blog.setAuthor(blogRs.getString("username"));
                blog.setImage(blogRs.getString("image"));
                blog.setCreatedAt(blogRs.getTimestamp("created_at"));

                // Fetch the like count for the current blog
                String likeCountSql = "SELECT COUNT(*) AS total_likes FROM Likes WHERE blog_id = ?";
                PreparedStatement likeCountStmt = conn.prepareStatement(likeCountSql);
                likeCountStmt.setInt(1, blog.getId());
                ResultSet likeCountRs = likeCountStmt.executeQuery();
                if (likeCountRs.next()) {
                    blog.setLikeCount(likeCountRs.getInt("total_likes"));
                }
                likeCountRs.close();
                likeCountStmt.close();

                // Add the blog to the list
                blogs.add(blog);
            }
            blogRs.close();
            blogStmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Set the blogs in the request scope
        request.setAttribute("blogs", blogs);

        // Forward the request to the JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.forward(request, response);
    }
}
