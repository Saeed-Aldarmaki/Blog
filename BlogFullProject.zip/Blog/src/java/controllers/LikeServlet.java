package controllers;

import utils.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/LikeServlet")
public class LikeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        models.User user = (models.User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("index.jsp"); // Redirect to login if user is not logged in
            return;
        }

        int userId = user.getId();
        int blogId = Integer.parseInt(request.getParameter("blog_id"));
        String action = request.getParameter("action");

        try (Connection conn = DBConnection.getConnection()) {
            if ("like".equals(action)) {
                // Add like
                String likeSql = "INSERT INTO Likes (user_id, blog_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE blog_id = blog_id";
                try (PreparedStatement stmt = conn.prepareStatement(likeSql)) {
                    stmt.setInt(1, userId);
                    stmt.setInt(2, blogId);
                    stmt.executeUpdate();
                }
            } else if ("unlike".equals(action)) {
                // Remove like
                String unlikeSql = "DELETE FROM Likes WHERE user_id = ? AND blog_id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(unlikeSql)) {
                    stmt.setInt(1, userId);
                    stmt.setInt(2, blogId);
                    stmt.executeUpdate();
                }
            }

            // Redirect back to the blog details page
            response.sendRedirect("BlogServlet?id=" + blogId);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }
}
