package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import models.User;
import utils.DBConnection;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // SQL query to verify if the email and password match
        String sql = "SELECT user_id, username, email, password_hash FROM users WHERE email = ? AND password_hash = ?";

        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Connection con = null;
        
        try {
            // Prepare the SQL query
            con = DBConnection.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, email);
            pstmt.setString(2, password); // In a real application, hash the password before comparison

            // Execute the query
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Login successful, redirect to main.jsp
                int userId = rs.getInt("user_id");

                User user = new User();
                user.setId(rs.getInt("user_id")); // Correct column name
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));

                HttpSession session = request.getSession();
                session.setAttribute("user", user);

                response.sendRedirect("HomeServlet");
            } else {
                // Invalid login, redirect back to login page with error
                request.setAttribute("errorMessage", "Invalid email or password.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
                dispatcher.forward(request, response);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().println("<p>Database Driver error: " + e.getMessage() + "</p>");
        } catch (SQLException e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().println("<p>Error logging in: " + e.getMessage() + "</p>");
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

