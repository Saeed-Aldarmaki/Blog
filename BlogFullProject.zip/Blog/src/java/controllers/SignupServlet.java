package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import utils.DBConnection;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validate input
        if (username == null || email == null || password == null || 
            username.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty()) {
            request.setAttribute("errorMessage", "All fields are required.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("signup.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // SQL query to insert a new user
        String sql = "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)";


        try {
        Connection con = DBConnection.getConnection();
        PreparedStatement pstmt = con.prepareStatement(sql);

            // Set query parameters
            pstmt.setString(1, username);
            pstmt.setString(2, email);
            pstmt.setString(3, password); 

            // Execute the insert operation
            int result = pstmt.executeUpdate();

            if (result > 0) {
                // Registration successful
                request.setAttribute("successMessage", "User registered successfully! You can now log in.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
                dispatcher.forward(request, response);
            } else {
                // Failed to insert the user
                request.setAttribute("errorMessage", "Failed to register user. Please try again.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("signup.jsp");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().contains("Duplicate entry")) {
                // Duplicate email error
                request.setAttribute("errorMessage", "Email is already registered.");
            } else {
                request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("signup.jsp");
            dispatcher.forward(request, response);
        }
    }
}
