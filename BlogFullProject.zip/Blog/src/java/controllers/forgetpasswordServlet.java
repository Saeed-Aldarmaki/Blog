import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/forgetpasswordServlet")
public class forgetpasswordServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String email = request.getParameter("email");
        String newPassword = request.getParameter("newPassword");

        // Database connection parameters
        String databaseURL = "jdbc:mysql://localhost:3306/blog";
        String driverName = "com.mysql.cj.jdbc.Driver";
        String user = "root";
        String dbPassword = "root";

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName(driverName).newInstance();

            // Establish connection to the database
            con = DriverManager.getConnection(databaseURL, user, dbPassword);

            // Check if email exists in the database
            String checkEmailSql = "SELECT * FROM users WHERE email = ?";
            pstmt = con.prepareStatement(checkEmailSql);
            pstmt.setString(1, email);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // If email exists, update the password
                String updatePasswordSql = "UPDATE users SET password_hash = ? WHERE email = ?";
                pstmt = con.prepareStatement(updatePasswordSql);
                pstmt.setString(1, newPassword); // In a real application, password should be hashed
                pstmt.setString(2, email);

                int result = pstmt.executeUpdate();

                if (result > 0) {
                    // Password reset successful, set message and redirect to index.jsp
                    
                    response.sendRedirect("password-success.jsp");
                } else {
                    // Something went wrong with updating the password
                    
                    response.sendRedirect("password-fail.jsp");
                }
            } else {
                // Email doesn't exist in the database
                response.sendRedirect("password-fail.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute("resetMessage", "Error occurred: " + e.getMessage());
            response.sendRedirect("index.jsp");
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Forget Password Servlet";
    }
}
