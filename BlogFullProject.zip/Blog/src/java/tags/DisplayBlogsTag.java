package tags;

import java.util.List;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import models.Blog;

/**
 *
 * @author USER
 */
public class DisplayBlogsTag extends SimpleTagSupport {

    private List<Blog> blogs;

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
    @Override
    public void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
            if (blogs != null && !blogs.isEmpty()) {
                out.println("<div class='posts-container'>");
                for (Blog blog : blogs) {
                    out.println("<div class='post-card'>");
                    out.println("<img src='" + blog.getImage() + "' alt='Post Image' class='post-image' />");
                    out.println("<h2>" + blog.getTitle() + "</h2>");
                    String truncatedContent = blog.getContent().length() > 356
                            ? blog.getContent().substring(0, 356) + "..."
                            : blog.getContent();
                    out.println("<p>" + truncatedContent + "</p>");
                    out.println("<p><small>Written by: " + blog.getAuthor() + "</small></p>");
                    out.println("<p><small>Posted on: " + blog.getFormattedDate()+ "</small></p>");
                    out.println("<p><small>Likes: " + blog.getLikeCount()+ "</small></p>");
                    out.println("<a href='BlogServlet?id=" + blog.getId() + "' class='read-more'>Read More</a>");
                    out.println("</div>");
                }
                out.println("</div>");
            } else {
                out.println("<p>No posts available.</p>");
            }
        } catch (java.io.IOException ex) {
            throw new JspException("Error in DisplayBlogsTag tag", ex);
        }
    }

    public void setBlogs(List blogs) {
        this.blogs = blogs;
    }
    
}
